#!/bin/sh
python3 basic_3.py "$1" "$2"
