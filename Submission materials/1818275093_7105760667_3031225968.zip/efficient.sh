#!/bin/sh
python3 efficient_3.py "$1" "$2"
